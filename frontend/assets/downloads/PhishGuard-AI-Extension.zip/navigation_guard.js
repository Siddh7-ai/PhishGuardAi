// Navigation Guard - Scan async, only redirect if Phishing confirmed

import apiClient from './api_client.js';

class NavigationGuard {
  constructor() {
    this.scanningUrls  = new Set();   // URLs currently being scanned
    this.blockedTabs   = new Set();   // tabs being redirected to blocked.html
    this.tabAllowlist  = new Map();   // tab-scoped user bypasses
  }

  init() {
    chrome.webNavigation.onBeforeNavigate.addListener(
      (details) => this.handleNavigation(details),
      { url: [{ schemes: ['http', 'https'] }] }
    );

    chrome.tabs.onRemoved.addListener((tabId) => {
      this.tabAllowlist.delete(tabId);
      this.blockedTabs.delete(tabId);
    });

    console.log('✓ Navigation guard initialized');
  }

  allowUrlForTab(tabId, url) {
    if (!this.tabAllowlist.has(tabId)) {
      this.tabAllowlist.set(tabId, new Set());
    }
    this.tabAllowlist.get(tabId).add(url);
    console.log(`✅ Tab ${tabId} bypass: ${url}`);
  }

  async handleNavigation(details) {
    if (details.frameId !== 0) return;

    const { url, tabId } = details;

    // Skip internal browser/extension pages
    if (!url.startsWith('http://') && !url.startsWith('https://')) return;

    // Skip if we redirected this tab to blocked.html (avoid scan loop)
    if (this.blockedTabs.has(tabId)) return;

    // Skip if user bypassed this URL for this tab
    const allowed = this.tabAllowlist.get(tabId);
    if (allowed && allowed.has(url)) {
      console.log(`✅ Bypass active — skipping: ${url}`);
      return;
    }

    // Skip if this exact URL is already being scanned (dedup)
    const key = `${tabId}:${url}`;
    if (this.scanningUrls.has(key)) return;
    this.scanningUrls.add(key);

    try {
      console.log('🔍 Scanning:', url);
      const result = await apiClient.scanURL(url);
      console.log(`📊 Result: ${result.classification} — ${url}`);

      if (result.classification === 'Phishing') {
        await this.blockTab(tabId, url, result);
      }
      // Safe/Suspicious/Error → do nothing, user stays on page normally

    } catch (err) {
      console.error('✗ Scan error (fail open):', err);
    } finally {
      // Clean up after 5s to allow re-scan if user navigates back
      setTimeout(() => this.scanningUrls.delete(key), 5000);
    }
  }

  async blockTab(tabId, url, result) {
    try {
      this.blockedTabs.add(tabId);

      await chrome.storage.local.set({
        lastDetection: {
          originalUrl:    url,
          url:            url,
          classification: result.classification,
          confidence:     result.confidence  ?? 95,
          risk_level:     result.risk_level  ?? 'high',
          modules:        result.modules     || {},
          timestamp:      Date.now()
        }
      });

      const blockedPage = chrome.runtime.getURL('blocked.html');
      await chrome.tabs.update(tabId, { url: blockedPage });
      console.log('🚫 Blocked tab redirected:', url);

    } catch (err) {
      console.error('✗ Block error:', err);
      this.blockedTabs.delete(tabId);
    } finally {
      // Release block lock after 4s
      setTimeout(() => this.blockedTabs.delete(tabId), 4000);
    }
  }
}

const navigationGuard = new NavigationGuard();
export default navigationGuard;
