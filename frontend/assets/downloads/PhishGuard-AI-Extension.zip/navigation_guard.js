// Navigation Guard - Intercept early, redirect immediately, scan from blocked page

import apiClient from './api_client.js';

class NavigationGuard {
  constructor() {
    this.pendingNavigations = new Set();
    this.blockedTabs = new Set();
    this.tabAllowlist = new Map();
    // URLs currently being scanned — store result so blocked_page.js can fetch it
    this.scanResults = new Map(); // url -> result
  }

  init() {
    // onBeforeNavigate fires BEFORE the page starts loading — intercept here
    chrome.webNavigation.onBeforeNavigate.addListener(
      (details) => this.handleNavigation(details),
      { url: [{ schemes: ['http', 'https'] }] }
    );

    chrome.tabs.onRemoved.addListener((tabId) => {
      this.tabAllowlist.delete(tabId);
      this.blockedTabs.delete(tabId);
    });

    console.log('✓ Navigation guard initialized');
  }

  allowUrlForTab(tabId, url) {
    if (!this.tabAllowlist.has(tabId)) {
      this.tabAllowlist.set(tabId, new Set());
    }
    this.tabAllowlist.get(tabId).add(url);
    console.log(`✅ Tab ${tabId} bypass granted for: ${url}`);
  }

  getScanResult(url) {
    return this.scanResults.get(url) || null;
  }

  async handleNavigation(details) {
    if (details.frameId !== 0) return;

    const url   = details.url;
    const tabId = details.tabId;

    // Skip internal pages
    if (url.startsWith('chrome-extension://') || url.startsWith('chrome://') ||
        url.startsWith('about:') || url.startsWith('file:')) return;

    // Skip if we are the ones redirecting to blocked.html
    if (this.blockedTabs.has(tabId)) {
      console.log('⏭ Skipping — tab is being redirected:', tabId);
      return;
    }

    // Skip if user bypassed this URL for this tab
    const tabUrls = this.tabAllowlist.get(tabId);
    if (tabUrls && tabUrls.has(url)) {
      console.log(`✅ Bypass active for tab ${tabId}: ${url}`);
      return;
    }

    // Deduplicate concurrent navigations for same tab+url
    const navKey = `${tabId}-${url}`;
    if (this.pendingNavigations.has(navKey)) return;
    this.pendingNavigations.add(navKey);

    try {
      console.log('🔍 Intercepted navigation:', url);

      // ── Strategy: redirect IMMEDIATELY to scanning page, then scan ──────
      // This ensures the phishing site NEVER loads, even on slow backends.
      // blocked.html will show "Scanning..." state, get the result via message,
      // and either show the warning (phishing) or redirect back (safe).

      this.blockedTabs.add(tabId);

      const encodedUrl = encodeURIComponent(url);
      const scanningPageUrl = chrome.runtime.getURL(`blocked.html?url=${encodedUrl}&state=scanning`);
      await chrome.tabs.update(tabId, { url: scanningPageUrl });

      // Now scan in background
      const result = await apiClient.scanURL(url);
      console.log(`📊 Scan result for ${url}:`, result.classification);

      // Store result so blocked_page.js can retrieve it via message
      this.scanResults.set(url, result);

      // Notify the blocked page tab with the result
      try {
        await chrome.tabs.sendMessage(tabId, {
          type:   'SCAN_RESULT',
          url:    url,
          result: result
        });
      } catch (_) {
        // Tab may have been closed or navigated away — that's fine
      }

    } catch (error) {
      console.error('✗ Navigation guard error:', error);
      // On unexpected error, allow navigation (fail open)
      this.blockedTabs.delete(tabId);
      try {
        await chrome.tabs.update(tabId, { url });
      } catch (_) {}
    } finally {
      setTimeout(() => {
        this.pendingNavigations.delete(navKey);
        this.blockedTabs.delete(tabId);
      }, 5000);
    }
  }
}

const navigationGuard = new NavigationGuard();
export default navigationGuard;
