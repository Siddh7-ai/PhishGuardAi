// blocked_page.js
// Handles two states:
//   ?state=scanning  → show spinner, wait for SCAN_RESULT message, then decide
//   ?state=blocked   → show full warning (set by this script after phishing confirmed)

(async () => {

  // ── Parse URL params ─────────────────────────────────────────────────────
  const params      = new URLSearchParams(window.location.search);
  const targetUrl   = params.get('url')   || null;
  const state       = params.get('state') || 'scanning';

  const scanningView = document.getElementById('scanningView');
  const blockedView  = document.getElementById('blockedView');

  // ── Show scanning URL label ──────────────────────────────────────────────
  const scanningUrlEl = document.getElementById('scanningUrl');
  if (scanningUrlEl && targetUrl) {
    const display = decodeURIComponent(targetUrl);
    scanningUrlEl.textContent = display.length > 60 ? display.substring(0, 60) + '...' : display;
  }

  // ── Helper: switch to blocked view ──────────────────────────────────────
  function showBlocked(result) {
    scanningView.classList.add('hidden');
    blockedView.classList.remove('hidden');

    const url = targetUrl ? decodeURIComponent(targetUrl) : 'Unknown URL';

    const blockedUrlEl = document.getElementById('blocked-url');
    if (blockedUrlEl) { blockedUrlEl.textContent = url; blockedUrlEl.title = url; }

    const riskEl = document.getElementById('risk-level');
    if (riskEl && result.risk_level) riskEl.textContent = result.risk_level.toUpperCase();

    const confEl = document.getElementById('confidence');
    if (confEl && result.confidence != null) confEl.textContent = Number(result.confidence).toFixed(2) + '%';

    const classEl = document.getElementById('classification');
    if (classEl && result.classification) classEl.textContent = result.classification;

    const tsEl = document.getElementById('timestamp');
    if (tsEl) {
      const now = new Date();
      tsEl.textContent = now.toLocaleTimeString('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: false
      });
    }

    wireButtons(url);
  }

  // ── Helper: redirect to safe site ───────────────────────────────────────
  async function redirectToSafe(url) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) await chrome.tabs.update(tab.id, { url });
      else window.location.href = url;
    } catch (_) {
      window.location.href = url;
    }
  }

  // ── Wire buttons on blocked view ─────────────────────────────────────────
  function wireButtons(originalUrl) {
    const goBackBtn  = document.getElementById('go-back');
    const proceedBtn = document.getElementById('proceed');

    if (goBackBtn) {
      goBackBtn.addEventListener('click', async () => {
        const go = window.confirm(
          '🛡️ You are about to leave this blocked page.\n\n' +
          '📌 You will be redirected to Google homepage.\n\n' +
          'Click OK to go to Google.'
        );
        if (!go) return;
        await redirectToSafe('https://www.google.com');
      });
    }

    if (proceedBtn) {
      proceedBtn.addEventListener('click', async () => {
        if (!originalUrl) { alert('Original URL unavailable.'); return; }

        const confirmed = window.confirm(
          '⚠️ DANGER: This site was flagged as PHISHING.\n\n' +
          'Proceeding may expose you to:\n' +
          '  • Password / credential theft\n' +
          '  • Financial fraud\n' +
          '  • Malware installation\n\n' +
          'Are you absolutely sure you want to continue?\n\n' +
          '📌 Note: This bypass only lasts for this tab.\n' +
          'If you close and reopen this tab, the site will be blocked again.'
        );

        if (!confirmed) return;

        try {
          await chrome.storage.local.remove('lastDetection');
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tab) {
            await chrome.runtime.sendMessage({
              type:  'ALLOW_URL_FOR_TAB',
              tabId: tab.id,
              url:   originalUrl
            });
            await chrome.tabs.update(tab.id, { url: originalUrl });
          } else {
            window.location.href = originalUrl;
          }
        } catch (err) {
          console.error('Proceed error:', err);
          window.location.href = originalUrl;
        }
      });
    }
  }

  // ── SCANNING STATE: listen for result from service worker ────────────────
  if (state === 'scanning' && targetUrl) {
    const decodedUrl = decodeURIComponent(targetUrl);

    // Listen for SCAN_RESULT pushed from navigation_guard via service worker
    chrome.runtime.onMessage.addListener(function handler(message) {
      if (message.type !== 'SCAN_RESULT' || message.url !== decodedUrl) return;
      chrome.runtime.onMessage.removeListener(handler);
      handleResult(message.result, decodedUrl);
    });

    // Also poll via GET_SCAN_RESULT in case message was sent before page loaded
    let pollAttempts = 0;
    const maxPolls = 60; // poll for up to 60s
    const pollInterval = setInterval(async () => {
      pollAttempts++;
      try {
        const resp = await chrome.runtime.sendMessage({ type: 'GET_SCAN_RESULT', url: decodedUrl });
        if (resp && resp.result) {
          clearInterval(pollInterval);
          handleResult(resp.result, decodedUrl);
        }
      } catch (_) { /* service worker may be waking up */ }

      if (pollAttempts >= maxPolls) {
        clearInterval(pollInterval);
        // Timed out — fail open, let user through
        console.warn('⏱ Scan timed out — redirecting to original URL');
        await redirectToSafe(decodedUrl);
      }
    }, 1000);
  }

  function handleResult(result, originalUrl) {
    if (!result) {
      // No result — fail open
      redirectToSafe(originalUrl);
      return;
    }

    if (result.classification === 'Phishing') {
      // Show the blocked warning
      showBlocked(result);
    } else {
      // Safe or Suspicious — redirect to the original URL
      console.log(`✅ ${result.classification} — redirecting to: ${originalUrl}`);
      redirectToSafe(originalUrl);
    }
  }

})();
