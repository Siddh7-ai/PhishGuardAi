// API Client - Backend ML Only
// Retry with exponential backoff for Render free tier cold starts

import CONFIG from './config.js';

class APIClient {
  constructor() {
    this.cache = new Map();
  }

  getCached(url) {
    const cached = this.cache.get(url);
    if (!cached) return null;
    const age = Date.now() - cached.timestamp;
    if (age > CONFIG.CACHE_TTL_MS) { this.cache.delete(url); return null; }
    return cached.result;
  }

  setCached(url, result) {
    this.cache.set(url, { result, timestamp: Date.now() });
    if (this.cache.size > 100) {
      this.cache.delete(this.cache.keys().next().value);
    }
  }

  async _fetchOnce(url, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(CONFIG.API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
        signal: controller.signal
      });
      clearTimeout(timer);
      if (!response.ok) throw new Error(`Backend error: ${response.status}`);
      return await response.json();
    } catch (err) {
      clearTimeout(timer);
      throw err;
    }
  }

  async scanURL(url) {
    try {
      const urlObj = new URL(url);
      const scheme = urlObj.protocol;
      if (['chrome:', 'chrome-extension:', 'about:', 'file:'].includes(scheme)) {
        return { url, classification: 'Legitimate', confidence: 0, risk_level: 'low', skipped: true };
      }
    } catch (e) { console.warn('URL parse error:', e); }

    const cached = this.getCached(url);
    if (cached) { console.log('⚡ Cache hit:', url); return cached; }

    // Retry 3 times: 15s → 20s → 25s with 1s/2s delays
    const timeouts = [15000, 20000, 25000];
    const delays   = [1000, 2000];
    let lastError  = null;

    for (let i = 0; i < timeouts.length; i++) {
      try {
        console.log(`🔍 Attempt ${i + 1}/${timeouts.length} (${timeouts[i] / 1000}s): ${url}`);
        const result = await this._fetchOnce(url, timeouts[i]);
        this.setCached(url, result);
        return result;
      } catch (err) {
        lastError = err;
        console.warn(`❌ Attempt ${i + 1} failed: ${err.message}`);
        if (i < delays.length) {
          await new Promise(r => setTimeout(r, delays[i]));
        }
      }
    }

    console.error('❌ All attempts failed for:', url);
    return { url, classification: 'Error', confidence: 0, risk_level: 'unknown', error: true };
  }

  clearCache() { this.cache.clear(); }
}

const apiClient = new APIClient();
export default apiClient;
