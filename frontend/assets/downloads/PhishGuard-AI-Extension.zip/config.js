// Configuration - ML Only (No Whitelist)

const CONFIG = {
  // Backend URL
  API_URL: 'https://phishguardai-nnez.onrender.com/api/scan',

  // Cache duration (15 minutes)
  CACHE_TTL_MS: 15 * 60 * 1000,

  // REQUEST_TIMEOUT_MS kept for reference but api_client now manages
  // per-attempt timeouts with retry: 15s → 20s → 25s
  REQUEST_TIMEOUT_MS: 15000,

  WHITELIST: []
};

export default CONFIG;
